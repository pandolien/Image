#include "CImg.h"
#include <QImage>
void CImg::Initialzation(){
	temp = false;
	Buf = NULL;
}
void CImg::Init(int n){
	Close();
	Buf = new BYTE[n];
}
void CImg::Init(int x,int y ,int h,int w){
	setGeometry(x,y,h,w);
}
void CImg::Close(){
	if(Buf)delete[](Buf);
	Buf = NULL;
	//w = 0;
	//h = 0;
}
void CImg::Read(const QString name){
	pixmap = QPixmap(name);
	w = pixmap.width();
	h = pixmap.height();
	if(pixmap.isNull()){
		temp = true;
		return;
	}
	//setPixmap(pixmap);
}
bool CImg::GrayBuf(){
	if(temp)return false;
	Init(h*w*4);
	int i = 0,j =0;
	int cnt = 0;
	QImage img = pixmap.toImage();
	if(img.isNull())return false;
	for(i = 0; i< h;i++){
		for(j = 0;j< w;j++){
			QRgb rgb = img.pixel(j,i);
			int r = qRed(rgb);
			int g = qGreen(rgb);
			int b = qBlue(rgb);
			int mean = (float)(r+g+b)/3;
			BYTE buf = mean;
			Buf[cnt++] = buf;
			Buf[cnt++] = buf;
			Buf[cnt++] = buf;
			Buf[cnt++] = 255;
		}
	}
	QImage img1 = QImage(Buf,w,h,QImage::Format_RGBA8888);
	pixmap = QPixmap::fromImage(img1);
	setPixmap(pixmap);
	return true;
}
bool CImg::RGBBuf(){
	int i = 0,j =0;
	int cnt = 0;
	if(temp)return false;
	Init(h*w*4);
	QImage img = pixmap.toImage();
	if(img.isNull())return false;
	for(i = 0; i< h;i++){
		for(j = 0;j< w;j++){
			QRgb rgb = img.pixel(j,i);
			int r = qRed(rgb);
			int g = qGreen(rgb);
			int b = qBlue(rgb);
			BYTE buf = r;
			Buf[cnt++] = buf;
			buf = g;
			Buf[cnt++] = buf;
			buf = b;
			Buf[cnt++] = buf;
			Buf[cnt++] = 255;
		}
	}
	QImage img1 = QImage(Buf,w,h,QImage::Format_RGBA8888);
	pixmap = QPixmap::fromImage(img1);
	setPixmap(pixmap);
	return true;
}

