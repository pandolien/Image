#include "CWindow.h"
void CWindow::Initialzation(){
	img = NULL;
}
void CWindow::Init(){
	img = new CImg(this);
	img1 = new CImg();
	graph = new CGraph();
	//img->Init(0,0,400,300);
	img->Read("../img/test.png");
	img->RGBBuf();
	img1->Read("../img/test.png");
	img1->GrayBuf();
	img1->show();
	float a[6] ={1.2,4.6,8,5,2,9};
	graph->SetLine(a,6);
	graph->Show(800,500);
	//img->show();
}
void CWindow::Close(){
	img->Close();
	if(img)delete(img);
	img1->Close();
	delete(img1);
	graph->Close();
	delete(graph);
}
void CWindow::SetSize(int w,int h){
	this->resize(w,h);
}
