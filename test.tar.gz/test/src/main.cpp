#include <QApplication>
#include "main.h"

int main(int argc,char *argv[]){
	QApplication app(argc,argv);
	CWindow win;
	win.SetSize(500,500);
	win.show();
	
	return app.exec();
}
