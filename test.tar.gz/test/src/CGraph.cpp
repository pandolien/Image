#include "CGraph.h"
void CGraph::Initialzation(){
	chart = new QChart();
}
void CGraph::Close(){
	
}
void CGraph::SetLine(BYTE *D,int n){
	QLineSeries *series = new QLineSeries();
	int i;
	for(i = 0;i< n;i++)series->append(i,D[i]);
	chart->addSeries(series);
	
}
void CGraph::SetLine(char *D,int n){
	QLineSeries *series = new QLineSeries();
	int i;
	for(i = 0;i< n;i++)series->append(i,D[i]);
	chart->addSeries(series);
}
void CGraph::SetLine(float *D,int n){
	QLineSeries *series = new QLineSeries();
	int i;
	for(i = 0;i< n;i++)series->append(i,D[i]);
	chart->addSeries(series);
}
void CGraph::SetLine(int *D,int n){
	QLineSeries *series = new QLineSeries();
	int i;
	for(i = 0;i< n;i++)series->append(i,D[i]);
	chart->addSeries(series);
}
void CGraph::Show(int w,int h){
	chart->createDefaultAxes();
	QChartView *view = new QChartView(chart);
	view->setRenderHint(QPainter::Antialiasing);
	view->setParent(this);
	view->move(0,0);
	view->resize(w,h);
	resize(w,h);
	show();
}
