#ifndef __MAINLOOP_H_
#define __MAINLOOP_H_
#include "CWindow.h"


#endif
