#ifndef __CIMG_H__
#define __CIMG_H__
#include <stdio.h>
#include <QLabel>
#include <QPixmap>
typedef unsigned char BYTE;
class CImg: public QLabel{
public:
	CImg(QWidget *parent = NULL):QLabel(parent){
		Initialzation();
	}
public:
	void Initialzation();
	void Init(int n);
	void Init(int,int,int,int);
	void Close();
public:
	bool temp;
	QPixmap pixmap;
	int w;
	int h;
	int RGB;
	BYTE *Buf;
public:
	bool GrayBuf();
	bool RGBBuf();
	void Read(const QString name);	
	
};
#endif
