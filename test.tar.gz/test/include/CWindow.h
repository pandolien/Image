#ifndef __CWINDOW_H__
#define __CWINDOW_H__
#include <QWidget>
#include <CImg.h>
#include "CGraph.h"
class CWindow: public QWidget{
public:
	CWindow(QWidget *parent = NULL):QWidget(parent){
		Initialzation();
		Init();
	}
	
	void closeEvent(QCloseEvent *evt)override{
		Close();
	}
public:
	void Initialzation();
	void Init();
	void Close();
private:
	CImg *img,*img1;
	CGraph *graph;
public:
	void SetSize(int,int);	
};
#endif
