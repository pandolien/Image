#ifndef __CGRAPH_H__
#define __CGRAPH_H__
#include <QWidget>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChartView>
#include <QtCharts/QChart>

#include "lPTRList.h"
typedef unsigned char BYTE;
QT_CHARTS_USE_NAMESPACE
class CGraph: public QWidget{
public:
	CGraph(QWidget *p = NULL):QWidget(p){
		Initialzation();
	}
public:
	void Initialzation(); 
	void Close();
public:
	QChart *chart;
public:
	void SetLine(BYTE*,int);
	void SetLine(char*,int);
	void SetLine(float*,int);
	void SetLine(int*,int);
	void Show(int,int);
};
#endif
